import express from 'express';
import 'reflect-metadata';

const app = express();
app.use(express.json());

app.get('/', (_req, res) => {
  res.send('Task Manager Backend Running!');
});

app.listen(3001, () => {
  console.log('Backend running at http://localhost:3001');
});