# Task Manager Backend

## How to Run

1. Install dependencies:
```bash
cd backend
npm install
```

2. Copy `.env.example` to `.env` and update credentials.

3. Start the backend server:
```bash
npm run dev
```

The backend will run at `http://localhost:3001`.